
public class SymbolException extends Exception {

	public SymbolException(String message) {
		super(message);
		
	}

}
