
/** CUP generated class containing symbol constants. */
public class sym {
  /* terminals */
  public static final int GE = 13;
  public static final int BVAL = 46;
  public static final int SLPAR = 19;
  public static final int INT = 33;
  public static final int FLOOR = 39;
  public static final int NOT = 8;
  public static final int AND = 6;
  public static final int LT = 10;
  public static final int RPAR = 16;
  public static final int FUN = 41;
  public static final int OR = 7;
  public static final int BOOL = 34;
  public static final int COMMA = 23;
  public static final int DIV = 5;
  public static final int BEGIN = 30;
  public static final int ASSIGN = 14;
  public static final int IF = 24;
  public static final int ID = 43;
  public static final int LE = 12;
  public static final int EOF = 0;
  public static final int RETURN = 42;
  public static final int SEMICLON = 22;
  public static final int EQUAL = 9;
  public static final int SIZE = 37;
  public static final int CLPAR = 17;
  public static final int error = 1;
  public static final int MUL = 4;
  public static final int ADD = 2;
  public static final int SRPAR = 20;
  public static final int REAL = 35;
  public static final int RVAL = 44;
  public static final int COLON = 21;
  public static final int ELSE = 29;
  public static final int READ = 28;
  public static final int WHILE = 26;
  public static final int FLOAT = 38;
  public static final int THEN = 25;
  public static final int END = 31;
  public static final int LPAR = 15;
  public static final int CEIL = 40;
  public static final int GT = 11;
  public static final int SUB = 3;
  public static final int VAR = 36;
  public static final int PRINT = 32;
  public static final int DO = 27;
  public static final int CRPAR = 18;
  public static final int IVAL = 45;
}

